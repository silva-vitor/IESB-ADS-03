    /*
01. Crie uma função que recebe um array de 2 números e coloque eles em ordem crescente. Não
use o método sort.
*/


let array = []

function array (n1, n2){
    array.push(n1)
    array.push(n2)
    
    

    array.push(n1)
    array.push(n2)
    

    


    if(n1 < n2){
        console.log(`${n1}, ${n2}`)

    }

    if(n1 > n2){
        console.log(`${n2}, ${n1}`)
    }
    

}

array(25, 5)


